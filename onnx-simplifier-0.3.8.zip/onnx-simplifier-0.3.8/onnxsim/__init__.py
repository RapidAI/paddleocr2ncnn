from onnxsim.onnx_simplifier import simplify, main

__version__ = '0.0.0'
